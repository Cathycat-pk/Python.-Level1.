import random

list = [random.randint(-100,100) for _ in range (10)]
print(list)

list1 = [i for i in list if i%3 == 0 and i >0 and i%4 !=0]
print(list1)

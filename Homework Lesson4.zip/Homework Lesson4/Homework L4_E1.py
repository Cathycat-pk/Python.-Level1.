s = str(input("Введите положительные или отрицательные целые числа через пробел: "))

try:
    a = [int(x) for x in s.split()]
    print("Возведем их в квадрат:")
    b = [i ** 2 for i in a]
    print(b)
except ValueError:
    print("Некорректный ввод, проверьте соответствие условию")

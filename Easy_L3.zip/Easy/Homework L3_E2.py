ticket_number = str(input("Введите номер билета из 6 цифр: "))

def lucky_ticket(ticket_number):
    sum1 = int(ticket_number[0]) + int(ticket_number[1]) + int(ticket_number[2])
    sum2 = int(ticket_number[3]) + int(ticket_number[4]) + int(ticket_number[5])

    if sum1 == sum2:
        return("Ваш билет счастливый");
    else:
        return("Не повезло")


print(lucky_ticket(ticket_number))
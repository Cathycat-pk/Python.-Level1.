def my_round (n, nd):
    n = n*(10**nd)
    n = n//1
    return n/(10**nd)

n = float(input("Введите десятичную дробь с разделителем точка: "))
nd = int(input("Введите нужное количество знаков после запятой: "))

a = (my_round(n, nd+1) - my_round(n, nd))
a = a*10**(nd+1)
if a>=5:
    n = (my_round(n, nd))+1/(10**nd)
else:
    n = (my_round(n, nd))

print(n)